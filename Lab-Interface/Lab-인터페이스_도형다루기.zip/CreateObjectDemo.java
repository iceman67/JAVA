public class CreateObjectDemo {

    public static void main(String[] args) {
		
        // Declare and create a point object and two rectangle objects.
        Point originOne = new Point(100, 100);
        Rectangle rectOne = new Rectangle(originOne, 100, 200);
        Rectangle rectTwo = new Rectangle(50, 100);
		
        // display rectOne's width, height, and area
        System.out.println("\n*Rectangle one*");
        System.out.println("Width of rectOne: " + rectOne.width);
        System.out.println("Height of rectOne: " + rectOne.height);
        System.out.println("Area of rectOne: " + rectOne.getArea());
		
        // set rectTwo's position
        rectTwo.origin = originOne;
		
        // display rectTwo's width, height, and area
        System.out.println("\n*Rectangle two*");
        System.out.println("Width of rectTwo: " + rectTwo.width);
        System.out.println("Height of rectTwo: " + rectTwo.height);
        System.out.println("Area of rectTwo: " + rectTwo.getArea());
        
        // display rectTwo's position
        System.out.println("X Position of rectTwo: " + rectTwo.origin.x);
        System.out.println("Y Position of rectTwo: " + rectTwo.origin.y);
		
        System.out.println("*Move rectTwo*" );
        // move rectTwo and display its new position
        rectTwo.move(40, 72);
        System.out.println("X Position of rectTwo: " + rectTwo.origin.x);
        System.out.println("Y Position of rectTwo: " + rectTwo.origin.y);
        
        
        Point originTwo = new Point(200, 200);
        Triangle triOne = new Triangle(originTwo, 100, 200);
        
        System.out.println("\n*Triangle one*");
        // display triOne's position
        System.out.println("X Position of triOne: " + triOne.origin.x);
        System.out.println("Y Position of triOne: " + triOne.origin.y);
        // display triOne's width, height, and area
        System.out.println("Width of triOne: " + triOne.width);
        System.out.println("Height of triOne: " + triOne.height);
		
        System.out.println("Area of triOne: " + triOne.getArea());
        
        
        Diagram[] arrDiagram = {rectOne, rectTwo, triOne};
        System.out.println("\n*Diagram Array *");
        for (Diagram diagram :  arrDiagram) {
        	 System.out.println("Area of diagram : " + diagram.getArea());
        }
    }
}
