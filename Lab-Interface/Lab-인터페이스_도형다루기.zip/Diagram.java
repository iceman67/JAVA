interface Diagram {
	int getArea();
}
