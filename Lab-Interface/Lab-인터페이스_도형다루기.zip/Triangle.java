
public class Triangle implements Diagram {

    public Point origin;
    int width, height;
    // four constructors
    public Triangle() {
	    origin = new Point(0, 0);
    }
    public Triangle(Point p) {
	    origin = p;
    }
    public Triangle(int w, int h) {
	    origin = new Point(0, 0);
	    width = w;
	    height = h;
    }
    public Triangle(Point p, int w, int h) {
	   origin = p;
	   width = w;
	   height = h;
    }
    @Override
	public int getArea() {
		// TODO Auto-generated method stub
	    return (width * height) / 2;  
    }

}


 
    

   